import argparse
import re
import time
from pathlib import Path
from playwright.sync_api import sync_playwright, Error as PlaywrightError

ROOT = Path(__file__).resolve().parent
PROFILE = ROOT / "browser_profile"
FASTVPN_URL = "https://fastz.vip/"
LOG_FILE = ROOT / "browser.log"

# Почтовые сервисы — перебираются по очереди (без антибота)
MAIL_SERVICES = [
    {"name": "tempmail.world", "url": "https://tempmail.world/ru", "read_fn": "read_mail_tempmail_world", "open_fn": "open_mailbox_tempmail_world"},
    {"name": "tempail", "url": "https://tempail.com/ru/", "read_fn": "read_mail_tempail", "open_fn": "open_mailbox_tempail"},
]

parser = argparse.ArgumentParser()
parser.add_argument("--visible", action="store_true", help="Показать браузер")
parser.add_argument("--headless", action="store_true", help="Фоновый режим (по умолчанию)")
args = parser.parse_args()
headless = args.headless or not args.visible


def log(msg, flush=True):
    """Write to both console and log file."""
    print(msg, flush=flush)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(msg + "\n")


def open_tab(context, url, done_text):
    """Open url in a new tab with stealth and report the result."""
    page = context.new_page()
    # Stealth: подменяем navigator.webdriver и другие свойства ДО загрузки страницы
    page.add_init_script(
        "Object.defineProperty(navigator, 'webdriver', { get: () => undefined }); "
        "Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] }); "
        "Object.defineProperty(navigator, 'languages', { get: () => ['ru-RU', 'ru', 'en-US', 'en'] }); "
        "window.chrome = { runtime: {} }; "
        "Object.defineProperty(navigator, 'webdriver', { configurable: true, enumerable: false, get: () => undefined });"
    )
    try:
        page.goto(url, wait_until="domcontentloaded", timeout=60000)
        log(f"{done_text}: {url}", flush=True)
    except PlaywrightError as exc:
        log(f"Не удалось открыть вкладку {url}: {exc}", flush=True)
    return page


def read_mail_tempmail_world(mail_page):
    """Read email address from tempmail.world."""
    try:
        mail_page.wait_for_function(
            """() => {
                const selectors = ['input#email', 'input#mail', 'input#trsh_mail', 'input[readonly]', 'input[type=text]'];
                for (const sel of selectors) {
                    const el = document.querySelector(sel);
                    if (el) { const val = (el.value || el.textContent || '').trim(); if (val.includes('@')) return true; }
                }
                const all = document.querySelectorAll('div, span');
                for (const el of all) {
                    if (el.children.length === 0) { const text = el.textContent.trim(); if (text.includes('@') && text.includes('.')) return true; }
                }
                return false;
            }""",
            timeout=45000,
        )
        address = mail_page.evaluate(
            """() => {
                const selectors = ['input#email', 'input#mail', 'input#trsh_mail', 'input[readonly]', 'input[type=text]'];
                for (const sel of selectors) {
                    const el = document.querySelector(sel);
                    if (el) { const val = (el.value || el.textContent || '').trim(); if (val.includes('@')) return val; }
                }
                const all = document.querySelectorAll('div, span');
                for (const el of all) {
                    if (el.children.length === 0) { const text = el.textContent.trim(); if (text.includes('@') && text.includes('.')) return text; }
                }
                return '';
            }"""
        )
    except PlaywrightError as exc:
        log(f"Не удалось прочитать адрес почты (tempmail.world): {exc}", flush=True)
        return ""
    if not address or "@" not in address:
        log("Адрес почты на tempmail.world не найден — скопируй его вручную.", flush=True)
        return ""
    log(f"EMAIL:{address}", flush=True)
    return address


def open_mailbox_tempmail_world(mail_page):
    """tempmail.world обычно сразу показывает почту."""
    log("tempmail.world: почта доступна сразу.", flush=True)
    return True


def read_mail_tempail(mail_page):
    """Read email address from tempail.com."""
    try:
        mail_page.wait_for_function(
            """() => {
                const selectors = ['input#email', 'input#mail', 'input#trsh_mail', 'input[readonly]', 'input[type=text]', '.email-address', '.email'];
                for (const sel of selectors) {
                    const el = document.querySelector(sel);
                    if (el) { const val = (el.value || el.textContent || el.getAttribute('data-value') || '').trim(); if (val.includes('@')) return true; }
                }
                return false;
            }""",
            timeout=45000,
        )
        address = mail_page.evaluate(
            """() => {
                const selectors = ['input#email', 'input#mail', 'input#trsh_mail', 'input[readonly]', 'input[type=text]', '.email-address', '.email'];
                for (const sel of selectors) {
                    const el = document.querySelector(sel);
                    if (el) { const val = (el.value || el.textContent || el.getAttribute('data-value') || '').trim(); if (val.includes('@')) return val; }
                }
                return '';
            }"""
        )
    except PlaywrightError as exc:
        log(f"Не удалось прочитать адрес почты (tempail): {exc}", flush=True)
        return ""
    if not address or "@" not in address:
        log("Адрес почты на tempail не найден — скопируй его вручную.", flush=True)
        return ""
    log(f"EMAIL:{address}", flush=True)
    return address


def open_mailbox_tempail(mail_page):
    """tempail.com обычно сразу показывает почту."""
    log("tempail: почта доступна сразу.", flush=True)
    return True


def wait_for_email(mail_page, timeout=120):
    """Wait for an incoming email from FASTVPN and return its text content.
    
    Only triggers on FASTVPN keyword — no false positives from page headers.
    Returns the full page text once FASTVPN appears in the email list.
    """
    deadline = time.time() + timeout
    prev_content = ""
    while time.time() < deadline:
        current_content = mail_page.evaluate("function() { var body = document.body; if (!body) return ''; return body.innerText || body.textContent || ''; }")
        
        if current_content and current_content != prev_content:
            # Проверяем что появился FASTVPN в списке писем
            if "FASTVPN" in current_content:
                log(f"Пришло письмо FASTVPN! Контент: {current_content[:300]}", flush=True)
                return current_content
            # НЕ срабатываем на первый же контент — ждём FASTVPN или таймаут
        prev_content = current_content
        time.sleep(2)
    log(f"Письмо не пришло за {timeout} сек.", flush=True)
    return ""


def open_latest_fastvpn_email(mail_page):
    """Кликнуть на последнее письмо от FASTVPN и вернуть его содержимое."""
    # Сначала обновляем страницу
    try:
        mail_page.reload(timeout=15000)
        time.sleep(3)
    except PlaywrightError:
        pass
    
    # Ждём появления списка писем с FASTVPN — более широкие селекторы
    deadline = time.time() + 45
    while time.time() < deadline:
        has_fastvpn = mail_page.evaluate("""function() {
            var selectors = [
                'li', '[class*="mail-item"]', '[class*="email-item"]', '[class*="message-row"]',
                '[class*="mail-list"] li', '[class*="inbox"] li',
                '[class*="message"]', '[class*="mail-row"]',
                '.mail-item', '.email-item', '.message', '.inbox-item'
            ];
            for (var s = 0; s < selectors.length; s++) {
                var items = document.querySelectorAll(selectors[s]);
                for (var i = 0; i < items.length; i++) {
                    if (items[i].textContent.indexOf('FASTVPN') !== -1) return true;
                }
            }
            var all = document.querySelectorAll('div, li, span, a, tr, td');
            for (var j = 0; j < all.length; j++) {
                if (all[j].textContent.indexOf('FASTVPN') !== -1 && all[j].offsetParent !== null) {
                    return true;
                }
            }
            return false;
        }""")
        if has_fastvpn:
            log("Найдены письма FASTVPN на странице.", flush=True)
            break
        time.sleep(1)
    
    # Клик на последнее FASTVPN письмо — несколько стратегий
    click_result = mail_page.evaluate("""function() {
        var sel1 = document.querySelectorAll('[class*="mail-item"], [class*="email-item"], [class*="message-row"], [class*="mail-list"] li, [class*="inbox"] li, [class*="mail-row"]');
        var fastvpn1 = [];
        for (var i = 0; i < sel1.length; i++) {
            if (sel1[i].textContent.indexOf('FASTVPN') !== -1) fastvpn1.push(sel1[i]);
        }
        if (fastvpn1.length > 0) {
            fastvpn1[fastvpn1.length - 1].click();
            return 'clicked via class selector';
        }
        var all = document.querySelectorAll('div, li, span, a, tr, td, p, h3, h4, b');
        var fastvpn2 = [];
        for (var j = 0; j < all.length; j++) {
            if (all[j].textContent.indexOf('FASTVPN') !== -1 && all[j].offsetParent !== null && (all[j].children.length === 0 || all[j].querySelector('ul, ol') === null)) {
                fastvpn2.push(all[j]);
            }
        }
        if (fastvpn2.length > 0) {
            fastvpn2[fastvpn2.length - 1].click();
            return 'clicked via text search';
        }
        return 'not found';
    }""")
    log(f"Клик на письмо: {click_result}", flush=True)
    time.sleep(3)
    
    # Читаем тело письма
    body_text = mail_page.evaluate("function() { var body = document.body; return body ? (body.innerText || body.textContent || '') : ''; }").strip()
    log(f"Тело письма ({len(body_text)} символов): {body_text[:500]}", flush=True)
    return body_text


def extract_code(email_text):
    """Извлечь 6-значный код из текста письма."""
    if not email_text:
        return ""
    
    # Вариант 1: код после метки (код:, code:, verification:, и т.д.)
    match = re.search(r'(?:код|code|verification|код подтверждения|verify|код для входа|your code)[:\s]*([A-Za-z0-9]{4,8})', email_text, re.IGNORECASE)
    if match:
        code = match.group(1)
        if code.isdigit() and len(code) == 6:
            log(f"Код найден (с меткой): {code}", flush=True)
            return code
    
    # Вариант 2: просто 6 цифр
    match = re.search(r'\b(\d{6})\b', email_text)
    if match:
        code = match.group(1)
        log(f"Код найден (6 цифр): {code}", flush=True)
        return code
    
    # Вариант 3: код в HTML (data-code, contenteditable, и т.д.)
    match = re.search(r'data-code["\s:=]+([A-Za-z0-9]{4,8})', email_text, re.IGNORECASE)
    if match:
        code = match.group(1)
        log(f"Код найден (data-code): {code}", flush=True)
        return code
    
    log("Код не найден в письме.", flush=True)
    return ""


def dismiss_cookies(page):
    """Close the cookie banner: it overlaps the header and swallows clicks."""
    for name in ("Только необходимые", "Принять"):
        try:
            button = page.get_by_role("button", name=name, exact=True).first
            if button.count() and button.is_visible():
                button.click(timeout=3000)
                log("Баннер cookie закрыт.", flush=True)
                return True
        except PlaywrightError:
            continue
    return False


def open_login_form(page, email=""):
    """Click the site's «Войти» button, fill the email field, and click «Продолжить»."""
    try:
        page.wait_for_load_state("networkidle", timeout=15000)
    except PlaywrightError:
        pass
    dismiss_cookies(page)

    candidates = [
        page.locator("button.public-login-button"),
        page.get_by_role("button", name="Войти", exact=True),
        page.locator("button", has_text=re.compile(r"^\s*Войти\s*$")),
    ]
    clicked = False
    for locator in candidates:
        try:
            target = locator.first
            target.wait_for(state="visible", timeout=8000)
            target.click(timeout=5000)
            clicked = True
            break
        except PlaywrightError:
            try:
                target.evaluate("el => el.click()")
                clicked = True
                break
            except PlaywrightError:
                continue

    if not clicked:
        log("Кнопка «Войти» не найдена — нажми её вручную.", flush=True)
        return False

    log("Форма входа открыта.", flush=True)
    try:
        field = page.locator('input[type="email"], input[name="email"]').first
        field.wait_for(state="visible", timeout=8000)
        if email and "@" in email:
            field.fill(email)
            log(f"Почта вставлена: {email}", flush=True)
            time.sleep(1)
            clicked = False
            for attempt in range(3):
                try:
                    btn = page.locator('button.button.primary.full').first
                    if btn.count() and btn.is_visible(timeout=3000):
                        btn.click(timeout=5000)
                        log("Кнопка «Продолжить» нажата.", flush=True)
                        clicked = True
                        break
                except PlaywrightError:
                    pass
                
                if not clicked:
                    result = page.evaluate("""function() {
                        var all = document.querySelectorAll('button');
                        for (var i = 0; i < all.length; i++) {
                            if (all[i].textContent.trim().toLowerCase().indexOf('продолжить') !== -1) {
                                all[i].click();
                                return 'clicked';
                            }
                        }
                        return 'not found';
                    }""")
                    if result == 'clicked':
                        log("Кнопка «Продолжить» нажата.", flush=True)
                        clicked = True
                        break
                time.sleep(0.5)
            if not clicked:
                log("Кнопка «Продолжить» не найдена — нажми вручную.", flush=True)
        else:
            field.click(timeout=3000)
            log("Поле ввода почты активно — вставь адрес из буфера (Ctrl+V).", flush=True)
    except PlaywrightError:
        pass
    return True


def run(headless=False, profile=PROFILE):
    log("Подготовка постоянного профиля браузера…", flush=True)
    Path(profile).mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        log("Запускаю Chromium в видимом режиме…" if not headless else "Запускаю Chromium…", flush=True)
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(profile),
            headless=headless,
            viewport={"width": 1365, "height": 900},
            args=[
                "--disable-dev-shm-usage",
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-extensions",
                "--disable-gpu",
            ],
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
        )
        # Очищаем данные для fastz.vip перед каждым запуском
        log("Очищаю данные fastz.vip (cookies, localStorage)…", flush=True)
        context.clear_cookies()
        try:
            clean_page = context.new_page()
            clean_page.goto(FASTVPN_URL, wait_until="domcontentloaded", timeout=15000)
            clean_page.evaluate("""function() {
                localStorage.clear();
                sessionStorage.clear();
                indexedDB.deleteDatabase('fastvpn');
            }""")
            clean_page.close()
            log("Данные очищены.", flush=True)
        except PlaywrightError:
            log("Не удалось очистить данные.", flush=True)
        try:
            vpn_page = context.pages[0] if context.pages else context.new_page()
            try:
                vpn_page.goto(FASTVPN_URL, wait_until="domcontentloaded", timeout=60000)
                log(f"FASTVPN загружен: {FASTVPN_URL}", flush=True)
            except PlaywrightError as exc:
                log(f"Не удалось открыть FASTVPN: {exc}", flush=True)

            email = ""
            mail_page = None
            for svc in MAIL_SERVICES:
                log(f"\n--- Пробуем почтовый сервис: {svc['name']} ---", flush=True)
                if mail_page:
                    try:
                        mail_page.close()
                    except PlaywrightError:
                        pass
                mail_page = open_tab(context, svc["url"], f"Почта загружена ({svc['name']})")
                
                read_fn = globals().get(svc["read_fn"])
                if read_fn:
                    email = read_fn(mail_page)
                else:
                    log(f"Функция чтения {svc['read_fn']} не найдена!", flush=True)
                    email = ""
                
                if email and "@" in email:
                    open_fn = globals().get(svc["open_fn"])
                    if open_fn:
                        open_fn(mail_page)
                    break
                else:
                    log(f"Почта не получена через {svc['name']}, пробуем следующий…", flush=True)

            if not email:
                log("Все почтовые сервисы не дали адрес — пробуй вручную.", flush=True)
                # Заменяем бесконечный цикл на таймаут + ручной режим
                deadline = time.time() + 120
                while time.time() < deadline:
                    time.sleep(1)
                log("Ручной режим: завершаю через 2 минуты ожидания.", flush=True)
                return

            vpn_page.bring_to_front()
            open_login_form(vpn_page, email)

            # Ждём кнопку "Войти по коду из письма" и нажимаем
            log("Ищем кнопку «Войти по коду из письма»…", flush=True)
            time.sleep(1.5)
            try:
                login_by_code_btn = vpn_page.get_by_text("Войти по коду из письма").first
                if login_by_code_btn.count() and login_by_code_btn.is_visible(timeout=5000):
                    login_by_code_btn.click(timeout=5000)
                    log("Кнопка «Войти по коду из письма» нажата.", flush=True)
                    time.sleep(1)
                else:
                    log("Кнопка «Войти по коду из письма» не найдена — проверяем другие варианты…", flush=True)
                    # Пробуем через evaluate
                    result = vpn_page.evaluate("""function() {
                        var buttons = document.querySelectorAll('button');
                        for (var i = 0; i < buttons.length; i++) {
                            if (buttons[i].textContent.indexOf('войти по коду из письма') !== -1 || buttons[i].textContent.indexOf('код из письма') !== -1) {
                                buttons[i].click();
                                return 'clicked';
                            }
                        }
                        return 'not found';
                    }""")
                    log(f"Результат клика: {result}", flush=True)
                    time.sleep(1)
            except PlaywrightError as exc:
                log(f"Ошибка при поиске кнопки «Войти по коду из письма»: {exc}", flush=True)

            # Ждём появления полей для кода (6 инпутов)
            log("Ждём появления полей для ввода кода…", flush=True)
            deadline = time.time() + 15
            while time.time() < deadline:
                code_fields = vpn_page.evaluate("""function() {
                    var inputs = document.querySelectorAll('input[inputmode="numeric"], input[pattern="[0-9]"], input[type="tel"]');
                    var count = 0;
                    for (var i = 0; i < inputs.length; i++) {
                        if (inputs[i].offsetParent !== null && (inputs[i].maxLength === 1 || inputs[i].pattern === "[0-9]")) {
                            count++;
                        }
                    }
                    return count;
                }""")
                if code_fields >= 6:
                    log(f"Найдено {code_fields} полей для кода.", flush=True)
                    break
                time.sleep(0.5)
            else:
                log("Поля для кода не найдены — пробуем искать письмо…", flush=True)

            # Ждём письмо от FASTVPN и открываем его
            log("Ждём письмо FASTVPN…", flush=True)
            email_content = wait_for_email(mail_page, timeout=90)
            
            if not email_content:
                log("Письмо не пришло! Пробуем открыть письмо вручную…", flush=True)
                time.sleep(2)
                email_content = mail_page.evaluate("function() { return document.body.innerText || ''; }").strip()
            
            # Открываем последнее письмо FASTVPN и читаем тело
            email_body = open_latest_fastvpn_email(mail_page)
            log(f"Тело письма: {email_body[:500]}", flush=True)
            code = extract_code(email_body)

            # Если код не найден, ищем просто 6 цифр в общем контенте (фоллбэк)
            if not code and email_content:
                log("Код не найден стандартным способом, ищу 6 цифр…", flush=True)
                matches = re.findall(r'\b(\d{6})\b', email_content)
                if matches:
                    code = matches[0]
                    log(f"Код найден как 6 цифр: {code}", flush=True)

            if code:
                log(f"Код найден: {code}. Вводим на FASTVPN…", flush=True)
                vpn_page.bring_to_front()
                time.sleep(0.5)
                
                # Цикл ввода кода — пробуем пока не войдём
                max_attempts = 3
                for attempt in range(max_attempts):
                    log(f"Попытка ввода кода: {attempt + 1}/{max_attempts}", flush=True)
                    
                    try:
                        # Несколько стратегий поиска полей для кода
                        code_inputs = None
                        actual_count = 0
                        
                        # Стратегия 1: стандартные классы
                        for selector in [
                            '.auth-code-group input',
                            '.auth-code-cells input',
                            'input[autocomplete="one-time-code"]',
                            'input[inputmode="numeric"][maxlength="1"]',
                            'input[type="tel"][maxlength="1"]',
                            'input.code-input',
                            'input.otp-input',
                            'input[name="code"]',
                            'input[name="otp"]',
                            'input#verification-code',
                        ]:
                            try:
                                test_inputs = vpn_page.locator(selector)
                                cnt = test_inputs.count()
                                if cnt >= 6:
                                    code_inputs = test_inputs
                                    actual_count = cnt
                                    log(f"Найдено {actual_count} полей через селектор: {selector}", flush=True)
                                    break
                            except PlaywrightError:
                                continue
                        
                        # Стратегия 2: через evaluate — ищем все input с maxlength=1
                        if code_inputs is None:
                            found_inputs = vpn_page.evaluate("""function() {
                                var all = document.querySelectorAll('input');
                                var result = [];
                                for (var i = 0; i < all.length; i++) {
                                    if (all[i].offsetParent !== null && (all[i].maxLength === 1 || all[i].pattern === '[0-9]')) {
                                        result.push(all[i]);
                                    }
                                }
                                return result;
                            }""")
                            if len(found_inputs) >= 6:
                                log(f"Найдено {len(found_inputs)} полей через evaluate (maxlength=1)", flush=True)
                                # Вводим через evaluate
                                code_filled = vpn_page.evaluate("function(code, inputs) { for (var i = 0; i < code.length && i < inputs.length; i++) { inputs[i].value = code[i]; inputs[i].dispatchEvent(new InputEvent('input', {bubbles: true})); inputs[i].dispatchEvent(new Event('change', {bubbles: true})); } return 'filled via evaluate'; }", code, found_inputs)
                                log(f"Ввод через evaluate: {code_filled}", flush=True)
                                actual_count = len(found_inputs)
                            else:
                                log(f"Не удалось найти поля для кода (найдено {len(found_inputs)} через evaluate)", flush=True)
                        
                        if code_inputs and actual_count >= 6:
                            for i, ch in enumerate(code):
                                if i < actual_count:
                                    code_inputs.nth(i).fill(ch)
                                    log(f"  Поле {i+1}: {ch}", flush=True)
                            log("Код введён через fill().", flush=True)
                        
                        time.sleep(1)
                        
                        # Нажимаем "Войти" — несколько стратегий
                        btn_clicked = False
                        for btn_sel in [
                            ('role', 'button', 'Войти'),
                            ('selector', 'button[type="submit"]'),
                            ('selector', 'button.primary.full'),
                            ('selector', 'button.button.primary'),
                        ]:
                            try:
                                if btn_sel[0] == 'role':
                                    btn = vpn_page.get_by_role(btn_sel[1], name=btn_sel[2], exact=True).first
                                    if btn.count() and btn.is_visible(timeout=3000):
                                        btn.click(timeout=5000)
                                        log(f"Кнопка «Войти» нажата через role (попытка {attempt + 1}).", flush=True)
                                        btn_clicked = True
                                        break
                                else:
                                    btn = vpn_page.locator(btn_sel[1]).first
                                    if btn.count() and btn.is_visible(timeout=3000):
                                        btn.click(timeout=5000)
                                        log(f"Кнопка «Войти» нажата через selector {btn_sel[1]} (попытка {attempt + 1}).", flush=True)
                                        btn_clicked = True
                                        break
                            except PlaywrightError:
                                continue
                        
                        if not btn_clicked:
                            # Фоллбэк: ищем через evaluate
                            result = vpn_page.evaluate("""function() {
                                var all = document.querySelectorAll('button');
                                for (var i = 0; i < all.length; i++) {
                                    if (all[i].textContent.trim() === 'Войти' && all[i].offsetParent !== null) {
                                        all[i].click();
                                        return 'clicked';
                                    }
                                }
                                return 'not found';
                            }""")
                            if result == 'clicked':
                                log(f"Кнопка «Войти» нажата через evaluate (попытка {attempt + 1}).", flush=True)
                                btn_clicked = True
                        
                        if not btn_clicked:
                            log("Кнопка «Войти» не найдена ни одной стратегией.", flush=True)
                    except PlaywrightError as exc:
                        log(f"Ошибка ввода кода: {exc}", flush=True)
                    
                    # Ждём результат
                    time.sleep(3)
                    
                    # Проверяем вошли ли — ищем элементы dashboard вместо кнопки "Войти"
                    dashboard_check = vpn_page.evaluate("""function() {
                        var body = document.body;
                        if (!body) return { logged_in: false, url: '' };
                        var text = body.textContent || '';
                        var dashboardSignals = [
                            'Партнёры', 'Подписка', 'Баланс', 'dashboard',
                            'subscription', 'hub-', 'Настройки', 'Платежи'
                        ];
                        for (var i = 0; i < dashboardSignals.length; i++) {
                            if (text.indexOf(dashboardSignals[i]) !== -1) return { logged_in: true, signal: dashboardSignals[i] };
                        }
                        var url = window.location.href;
                        if (url.indexOf('/dashboard') !== -1 || url.indexOf('/profile') !== -1 || url.indexOf('/settings') !== -1) {
                            return { logged_in: true, signal: 'url' };
                        }
                        return { logged_in: false, url: url };
                    }""")
                    
                    if dashboard_check.get('logged_in'):
                        log(f"Успешный вход! Сигнал: {dashboard_check.get('signal', 'unknown')}", flush=True)
                        break
                    else:
                        log(f"Вход не прошёл — повторяем. URL: {dashboard_check.get('url', 'unknown')}", flush=True)
                        time.sleep(2)

            # Ждём dashboard: проверяем наличие элементов dashboard
            log("Ждём перехода на dashboard…", flush=True)
            deadline = time.time() + 60
            entered = False
            while time.time() < deadline:
                # Проверяем наличие элементов dashboard вместо кнопки "Войти"
                dashboard_check = vpn_page.evaluate("""function() {
                    var body = document.body;
                    if (!body) return { logged_in: false, url: '' };
                    var text = body.textContent || '';
                    var url = window.location.href;
                    var dashboardSignals = [
                        'Партнёры', 'Подписка', 'Баланс', 'dashboard',
                        'subscription', 'hub-', 'Настройки', 'Платежи',
                        'Расширение для браузера', 'trial'
                    ];
                    for (var i = 0; i < dashboardSignals.length; i++) {
                        if (text.indexOf(dashboardSignals[i]) !== -1) return { logged_in: true, signal: dashboardSignals[i] };
                    }
                    if (url.indexOf('/dashboard') !== -1 || url.indexOf('/profile') !== -1 || url.indexOf('/settings') !== -1) {
                        return { logged_in: true, signal: 'url' };
                    }
                    return { logged_in: false, url: url };
                }""")
                
                if dashboard_check.get('logged_in'):
                    log(f"Dashboard обнаружен! Сигнал: {dashboard_check.get('signal', 'unknown')}", flush=True)
                    entered = True
                    break
                
                time.sleep(2)
            
            if not entered:
                log("Не удалось войти — пробуй вручную.", flush=True)
                deadline = time.time() + 120
                while time.time() < deadline:
                    time.sleep(1)
                log("Ручной режим: завершаю через 2 минуты ожидания.", flush=True)
                return
            
            # Закрываем все модальные окна
            log("Закрываем модальные окна…", flush=True)
            time.sleep(2)
            
            # Сначала закрываем модалку с Telegram (крестик в правом верхнем углу)
            try:
                close_result = vpn_page.evaluate("""function() {
                    var buttons = document.querySelectorAll('button');
                    for (var i = 0; i < buttons.length; i++) {
                        var btn = buttons[i];
                        var rect = btn.getBoundingClientRect();
                        var text = (btn.textContent || '').trim();
                        if (rect.width < 50 && rect.height < 50 && rect.top < 100 && rect.left > window.innerWidth - 200) {
                            if (text.indexOf('X') !== -1 || text === 'x') {
                                btn.click();
                                return 'clicked cross: ' + text;
                            }
                        }
                    }
                    var buttons2 = document.querySelectorAll('button');
                    for (var j = 0; j < buttons2.length; j++) {
                        var btn2 = buttons2[j];
                        var cls = (btn2.className || '').toString().toLowerCase();
                        var text2 = (btn2.textContent || '').trim();
                        if ((cls.indexOf('close') !== -1 || cls.indexOf('dismiss') !== -1 || cls.indexOf('modal-close') !== -1) && btn2.offsetParent !== null) {
                            btn2.click();
                            return 'clicked close btn';
                        }
                        if (text2 === 'X' || text2 === 'x') {
                            btn2.click();
                            return 'clicked symbol: ' + text2;
                        }
                    }
                    return 'not found';
                }""")
                log(f"Закрытие Telegram-модалки: {close_result}", flush=True)
                time.sleep(1)
            except PlaywrightError as exc:
                log(f"Ошибка закрытия Telegram-модалки: {exc}", flush=True)
            
            # Кнопка "Попробовать" (может быть несколько раз)
            for try_i in range(3):
                try:
                    try_btn = vpn_page.get_by_role("button", name="Попробовать", exact=True).first
                    if try_btn.count() and try_btn.is_visible(timeout=3000):
                        try_btn.click(timeout=5000)
                        log(f"Кнопка «Попробовать» нажата (попытка {try_i + 1}).", flush=True)
                        time.sleep(1)
                    else:
                        break
                except PlaywrightError:
                    break
            
            # Повторно закрываем модалку с Telegram (может появиться снова)
            for _ in range(2):
                try:
                    tg_result = vpn_page.evaluate("""function() {
                        var buttons = document.querySelectorAll('button');
                        for (var i = 0; i < buttons.length; i++) {
                            var btn = buttons[i];
                            var rect = btn.getBoundingClientRect();
                            var text = (btn.textContent || '').trim();
                            if (rect.width < 50 && rect.height < 50 && rect.top < 100 && rect.left > window.innerWidth - 200) {
                                if (text.indexOf('X') !== -1 || text === 'x') {
                                    btn.click();
                                    return 'clicked';
                                }
                            }
                        }
                        return 'not found';
                    }""")
                    if tg_result == 'clicked':
                        log("Telegram-модалка закрыта (повторно).", flush=True)
                        time.sleep(0.5)
                    else:
                        break
                except PlaywrightError:
                    break
            
            # Закрываем остальные модальные окна (X, close, dismiss)
            try:
                close_result2 = vpn_page.evaluate("""function() {
                    var buttons = document.querySelectorAll('button');
                    var closed = 0;
                    for (var i = 0; i < buttons.length; i++) {
                        var btn = buttons[i];
                        var cls = (btn.className || '').toString().toLowerCase();
                        if (cls.indexOf('close') !== -1 || cls.indexOf('dismiss') !== -1 || cls.indexOf('modal-close') !== -1) {
                            if (btn.offsetParent !== null) {
                                btn.click();
                                closed++;
                            }
                        }
                    }
                    return 'closed ' + closed + ' modals';
                }""")
                log(f"Закрытие остальных модалок: {close_result2}", flush=True)
            except PlaywrightError:
                pass
            
            time.sleep(2)
            log(f"URL страницы: {vpn_page.url}", flush=True)
            
            # Дебаг: выводим все кнопки на странице
            page_buttons = vpn_page.evaluate("""function() {
                var all = document.querySelectorAll('button, a, [role="button"]');
                var result = [];
                for (var i = 0; i < all.length; i++) {
                    if (all[i].offsetParent !== null) {
                        result.push({
                            text: (all[i].textContent || '').trim().substring(0, 40),
                            cls: all[i].className.substring(0, 50)
                        });
                    }
                }
                return result;
            }""")
            log(f"Кнопки на странице: {page_buttons[:15]}", flush=True)
            
            # Ищем ссылку подписки — несколько стратегий
            subscription_link = ""
            
            # Стратегия 1: кнопка "Скопировать ссылку подписки" (aria-label)
            try:
                copy_btn = vpn_page.locator('button[aria-label*="Скопировать"]').first
                if copy_btn.count() and copy_btn.is_visible(timeout=5000):
                    copy_btn.click(timeout=5000)
                    log("Кнопка копирования нажата (aria-label).", flush=True)
                    time.sleep(1)
            except PlaywrightError:
                log("Кнопка копирования (aria-label) не найдена.", flush=True)
            
            # ОТЛАДКА: выводим все элементы с "sub" или "link" в классе/тексте
            debug_elements = vpn_page.evaluate("""function() {
                var all = document.querySelectorAll('*');
                var found = [];
                for (var i = 0; i < all.length; i++) {
                    var el = all[i];
                    var cls = (el.className || '').toString().toLowerCase();
                    var text = (el.textContent || '').trim().substring(0, 100);
                    var title = (el.getAttribute('title') || '').substring(0, 100);
                    var href = (el.getAttribute('href') || '').substring(0, 100);
                    if (cls.indexOf('sub') !== -1 || cls.indexOf('link') !== -1 || cls.indexOf('copy') !== -1 ||
                        cls.indexOf('address') !== -1 || cls.indexOf('hub-sub') !== -1 ||
                        text.indexOf('sub.fast') !== -1 || title.indexOf('sub.fast') !== -1 ||
                        href.indexOf('sub.fast') !== -1) {
                        found.push({
                            tag: el.tagName,
                            cls: el.className.substring(0, 80),
                            text: text.substring(0, 80),
                            title: title.substring(0, 80),
                            href: href.substring(0, 80)
                        });
                    }
                }
                return found;
            }""")
            log(f"Элементы с sub/link/copy: {debug_elements}", flush=True)
            
            # Ищем ссылку через locator — класс .hub-subscription-address
            try:
                addr_btn = vpn_page.locator('button.hub-subscription-address').first
                if addr_btn.count() and addr_btn.is_visible(timeout=5000):
                    # Получаем title — там URL
                    title = addr_btn.get_attribute('title', timeout=3000)
                    if title and title.find('sub.fast') != -1:
                        subscription_link = title
                        log(f"Ссылка подписки (title): {subscription_link}", flush=True)
                    else:
                        # Получаем textContent
                        text = addr_btn.inner_text(timeout=3000)
                        if text.find('sub.fast') != -1:
                            idx = text.find('http://sub.fast')
                            if idx == -1:
                                idx = text.find('https://sub.fast')
                            if idx != -1:
                                rest = text[idx:]
                                url = ''
                                for j in range(len(rest)):
                                    ch = rest[j]
                                    if ch == ' ' or ch == '\n' or ch == '\t':
                                        break
                                    url += ch
                                subscription_link = url
                                log(f"Ссылка подписки (text): {subscription_link}", flush=True)
            except Exception as exc:
                log(f"Не удалось найти .hub-subscription-address: {exc}", flush=True)
            
            # Стратегия 2: ищем через locator .hub-subscription-link
            if not subscription_link:
                try:
                    link_div = vpn_page.locator('div.hub-subscription-link').first
                    if link_div.count() and link_div.is_visible(timeout=5000):
                        text = link_div.inner_text(timeout=3000)
                        if text.find('sub.fast') != -1:
                            idx = text.find('http://sub.fast')
                            if idx == -1:
                                idx = text.find('https://sub.fast')
                            if idx != -1:
                                rest = text[idx:]
                                url = ''
                                for j in range(len(rest)):
                                    ch = rest[j]
                                    if ch == ' ' or ch == '\n' or ch == '\t':
                                        break
                                    url += ch
                                subscription_link = url
                                log(f"Ссылка подписки (hub-subscription-link): {subscription_link}", flush=True)
                except Exception as exc:
                    log(f"Не удалось найти .hub-subscription-link: {exc}", flush=True)
            
            # Стратегия 3: ищем href у всех ссылок через locator
            if not subscription_link:
                try:
                    all_links = vpn_page.locator('a[href]')
                    for i in range(min(all_links.count(), 100)):
                        try:
                            href = all_links.nth(i).get_attribute('href', timeout=1000)
                            if href and href.find('sub.fast') != -1:
                                subscription_link = href
                                log(f"Ссылка подписки (href): {subscription_link}", flush=True)
                                break
                        except Exception:
                            continue
                except Exception as exc:
                    log(f"Не удалось найти ссылки: {exc}", flush=True)
            
            # Стратегия 3: ищем regex sub.fast во всём тексте + специальные селекторы
            if not subscription_link:
                subscription_link = vpn_page.evaluate("""function() {
                    // Сначала ищем regex
                    var all = document.querySelectorAll('a, button, p, span, div, h3, h4, strong, b, code, pre');
                    for (var i = 0; i < all.length; i++) {
                        var text = (all[i].textContent || all[i].getAttribute('title') || all[i].value || all[i].getAttribute('href') || '').trim();
                        var regex = new RegExp('https?:\\\\/\\\\/sub\\\\.fast[a-zA-Z0-9.-]+');
                        if (regex.test(text)) {
                            var match = text.match(regex);
                            return match[0];
                        }
                    }
                    // Затем ищем по специальным классам
                    var selectors = [
                        '.hub-subscription-address',
                        '.subscription-link',
                        '[class*="subscription"]',
                        '[class*="subscribe"]',
                        '[class*="link-subscription"]',
                        '[data-subscription-url]',
                        '[data-subscription]'
                    ];
                    for (var s = 0; s < selectors.length; s++) {
                        var el = document.querySelector(selectors[s]);
                        if (el) {
                            var title = el.getAttribute('title') || '';
                            if (title && title.startsWith('http')) return title;
                            var text = el.textContent.trim();
                            if (text.startsWith('http')) return text;
                            var url = el.getAttribute('data-url') || el.getAttribute('data-link') || '';
                            if (url.startsWith('http')) return url;
                        }
                    }
                    return '';
                }""")
            
            # Стратегия 4: ищем href у всех ссылок
            if not subscription_link:
                subscription_link = vpn_page.evaluate("""function() {
                    var all = document.querySelectorAll('a[href]');
                    for (var i = 0; i < all.length; i++) {
                        var href = all[i].getAttribute('href') || '';
                        if (href.indexOf('sub.fast') !== -1) return href;
                    }
                    return '';
                }""")
            
            # Стратегия 5: клик по кнопке "Скопировать" и чтение из буфера
            if not subscription_link:
                try:
                    copy_btn = vpn_page.locator('button').filter(has=vpn_page.get_by_text("Скопировать", ignore_case=True)).first
                    if copy_btn.count() and copy_btn.is_visible(timeout=3000):
                        copy_btn.click(timeout=3000)
                        log("Кнопка 'Скопировать' нажата, читаем буфер…", flush=True)
                        time.sleep(1)
                        subscription_link = vpn_page.evaluate("""function() {
                            if (navigator.clipboard && navigator.clipboard.readText) {
                                return navigator.clipboard.readText().catch(function() { return ''; });
                            }
                            return '';
                        }""")
                        # evaluate с async возвращает Promise — нужно дождаться
                        if hasattr(subscription_link, 'then'):
                            import asyncio
                            subscription_link = asyncio.get_event_loop().run_until_complete(subscription_link)
                        if subscription_link and subscription_link.startswith('http'):
                            log(f"Ссылка из буфера: {subscription_link}", flush=True)
                except Exception as exc:
                    log(f"Не удалось кликнуть 'Скопировать': {exc}", flush=True)
            
            # Стратегия 6: ищем все элементы с hub-sub классами
            if not subscription_link:
                subscription_link = vpn_page.evaluate("""function() {
                    var all = document.querySelectorAll('[class*="hub-sub"], [class*="sub-link"], [class*="sub-address"]');
                    for (var i = 0; i < all.length; i++) {
                        var title = all[i].getAttribute('title') || '';
                        if (title && title.indexOf('http') === 0) return title;
                        var text = all[i].textContent.trim();
                        if (text.indexOf('http') === 0) return text;
                    }
                    return '';
                }""")
                log("Ссылка подписки не найдена на странице — возможно, она в буфере обмена.", flush=True)
                log("Ссылка подписки не найдена — скопируй вручную.", flush=True)

            # Копируем ссылку в буфер обмена
            if subscription_link:
                try:
                    vpn_page.evaluate("""(url) => {
                        navigator.clipboard.writeText(url);
                    }""", subscription_link)
                    log("Ссылка подписки скопирована в буфер обмена.", flush=True)
                except Exception:
                    log("Не удалось скопировать ссылку — скопируй вручную.", flush=True)

                # Генерируем QR код для ссылки подписки
                try:
                    import urllib.request
                    import urllib.parse
                    import base64
                    
                    qr_url = f"https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={urllib.parse.quote(subscription_link)}"
                    qr_data = urllib.request.urlopen(qr_url, timeout=10).read()
                    qr_b64 = base64.b64encode(qr_data).decode('utf-8')
                    log(f"QR_CODE:{qr_b64}|{subscription_link}", flush=True)
                except Exception as exc:
                    log(f"Не удалось сгенерировать QR код: {exc}", flush=True)

            log("Готово! Ссылка подписки в буфере обмена.", flush=True)
            while True:
                try:
                    if not context.pages:
                        break
                except PlaywrightError:
                    break
                time.sleep(1)
            log("Все вкладки браузера закрыты.", flush=True)
        finally:
            try:
                context.close()
            except PlaywrightError:
                pass


if __name__ == "__main__":
    try:
        run(headless=headless)
    except PlaywrightError as exc:
        log(f"Playwright error: {exc}", flush=True)
        raise
    except Exception as exc:
        log(f"Unexpected error: {exc}", flush=True)
        raise
