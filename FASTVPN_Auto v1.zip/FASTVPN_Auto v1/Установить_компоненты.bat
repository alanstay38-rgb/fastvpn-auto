@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -m pip install -r requirements.txt
  if errorlevel 1 goto fail
  py -3 -m playwright install chromium
  if errorlevel 1 goto fail
  goto done
)
python -m pip install -r requirements.txt
if errorlevel 1 goto fail
python -m playwright install chromium
if errorlevel 1 goto fail
:done
echo.
echo Installation complete.
pause
exit /b 0
:fail
echo.
echo Installation failed. Check Python and internet connection.
pause
exit /b 1
