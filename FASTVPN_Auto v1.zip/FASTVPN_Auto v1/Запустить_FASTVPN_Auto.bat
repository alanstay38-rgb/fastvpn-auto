@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 fastvpn_manager.py
  goto end
)
python fastvpn_manager.py
:end
if errorlevel 1 pause
endlocal
