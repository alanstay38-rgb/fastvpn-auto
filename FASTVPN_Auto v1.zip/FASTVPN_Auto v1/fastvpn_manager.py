import base64
import io
import re
import sqlite3
import subprocess
import sys
import tkinter as tk
from tkinter import ttk
from datetime import datetime
from pathlib import Path
from PIL import Image, ImageTk

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "fastvpn_history.sqlite3"
PROFILE_DIR = APP_DIR / "browser_profile"
WORKER_LOG = APP_DIR / "browser_worker.log"
FASTVPN_URL = "https://fastz.vip/"
POLL_MS = 700

# Common VPN subscription URI schemes plus ordinary HTTPS subscription links.
URL_RE = re.compile(
    r"(?i)(?:https?://|vless://|vmess://|trojan://|ss://|ssr://|tuic://|hysteria2?://)\S+"
)

# ── Colors ──────────────────────────────────────────────────────────────
BG = "#0f1117"
CARD_BG = "#1a1d27"
INPUT_BG = "#141620"
PRIMARY = "#6c5ce7"
PRIMARY_HOVER = "#7c6ff7"
SUCCESS = "#00b894"
WARN = "#fdcb6e"
ERROR = "#ff7675"
TEXT = "#dfe6e9"
TEXT_DIM = "#636e72"
BORDER = "#2d3436"
HOVER = "#2d3436"

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("FASTVPN Auto")
        self.geometry("780x680")
        self.minsize(640, 560)
        self.configure(bg=BG)
        self.proc = None
        self.last_clipboard = ""
        self.subscription = ""
        self._progress_pct = 0
        self._animating = False
        self._progress_start = None
        self._progress_duration = 120  # секунд на полный цикл
        # Start from the current end of the worker log so old runs are not replayed.
        self.last_worker_log_size = WORKER_LOG.stat().st_size if WORKER_LOG.exists() else 0
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        init_db()
        self.build_ui()
        self.log("Приложение запущено.")
        self.log("Готово к работе. Нажми «Авто» или «Открыть сайты».")
        self.set_status("Ожидание", "Готово получить ссылку")
        self.after(POLL_MS, self.tick)
        # self._update_linear_progress()

    def build_ui(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        # ── Custom styles ───────────────────────────────────────────────
        style.configure("TFrame", bg=BG)
        style.configure("Card.TFrame", bg=CARD_BG, borderwidth=1, relief="solid")
        style.configure(
            "TLabel", background=BG, foreground=TEXT, font=("Segoe UI", 10)
        )
        style.configure(
            "Section.TLabel", background=CARD_BG, foreground=TEXT_DIM,
            font=("Segoe UI", 9, "bold"), padding=(0, 6),
        )
        style.configure(
            "Status.TLabel", background=CARD_BG, foreground=TEXT,
            font=("Segoe UI", 10, "bold"),
        )
        style.configure(
            "Detail.TLabel", background=CARD_BG, foreground=TEXT_DIM,
            font=("Segoe UI", 9),
        )
        style.configure(
            "TButton", font=("Segoe UI", 10, "bold"), padding=(16, 8),
            background=PRIMARY, foreground="#fff",
        )
        style.map("TButton",
                  background=[("active", PRIMARY_HOVER), ("disabled", BORDER)],
                  foreground=[("disabled", TEXT_DIM)])
        style.configure(
            "Outline.TButton", font=("Segoe UI", 10, "bold"), padding=(16, 8),
            background=CARD_BG, foreground=PRIMARY,
        )
        style.map("Outline.TButton",
                  background=[("active", HOVER)],
                  foreground=[("active", PRIMARY_HOVER), ("disabled", TEXT_DIM)])
        style.configure(
            "TScrollbar", arrowcolor=TEXT_DIM, troughcolor=CARD_BG,
            background=BORDER, width=8,
        )
        style.configure("Progressbar", troughcolor=BORDER, background=PRIMARY,
                        borderwidth=0, thickness=6)

        # ── Main container ──────────────────────────────────────────────
        main = tk.Frame(self, bg=BG)
        main.pack(fill="both", expand=True, padx=24, pady=24)

        # Title row with icon
        title_row = tk.Frame(main, bg=BG)
        title_row.pack(anchor="w", fill="x")
        try:
            icon_img = Image.open(APP_DIR / "icon.bin")
            icon_img = icon_img.resize((36, 36), Image.LANCZOS)
            self.icon_tk = ImageTk.PhotoImage(icon_img)
            tk.Label(title_row, image=self.icon_tk, bg=BG).pack(side="left", padx=(0, 12))
            # Set window icon
            self.iconphoto(True, self.icon_tk)
        except Exception:
            pass
        tk.Label(title_row, text="FASTVPN Auto", bg=BG, fg=TEXT,
                 font=("Segoe UI", 22, "bold")).pack(side="left", anchor="nw")
        tk.Label(main, text="Сделано Аланом для всадников и пиратства",
                 bg=BG, fg=TEXT_DIM, font=("Segoe UI", 10)).pack(
            anchor="w", pady=(2, 18)
        )

        # ── Action buttons ──────────────────────────────────────────────
        btn_frame = tk.Frame(main, bg=BG)
        btn_frame.pack(fill="x", pady=(0, 14))

        # Главная кнопка - Авто (получить ссылку)
        self.get_button = tk.Button(
            btn_frame, text="⚡  Получить ссылку", bg=PRIMARY, fg="#fff",
            font=("Segoe UI", 11, "bold"), border=0, cursor="hand2",
            padx=18, pady=10, relief="flat", command=self.get_link_auto,
        )
        self.get_button.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.get_button.bind("<Enter>", lambda e: self.get_button.config(bg=PRIMARY_HOVER))
        self.get_button.bind("<Leave>", lambda e: self.get_button.config(bg=PRIMARY))

        # Вторичная кнопка - Открыть сайты
        self.open_button = tk.Button(
            btn_frame, text="🔍  Открыть сайты", bg=CARD_BG, fg=TEXT_DIM,
            font=("Segoe UI", 10, "bold"), border=0, cursor="hand2",
            padx=16, pady=10, relief="flat", command=self.get_link_visible,
        )
        self.open_button.pack(side="left", fill="x", expand=True)
        self.open_button.bind("<Enter>", lambda e: self.open_button.config(bg=HOVER, fg=PRIMARY))
        self.open_button.bind("<Leave>", lambda e: self.open_button.config(bg=CARD_BG, fg=TEXT_DIM))

        # ── Status card ─────────────────────────────────────────────────
        status_card = tk.Frame(main, bg=CARD_BG, height=56, relief="flat")
        status_card.pack(fill="x", pady=(0, 14))
        status_card.pack_propagate(False)
        self.status_var = tk.StringVar(value="Ожидание")
        self.detail_var = tk.StringVar(value="Готово получить ссылку")
        self.status_label = tk.Label(status_card, textvariable=self.status_var,
                 bg=CARD_BG, fg=SUCCESS, font=("Segoe UI", 10, "bold"))
        self.status_label.pack(side="left", padx=16, pady=10)
        tk.Label(status_card, textvariable=self.detail_var,
                 bg=CARD_BG, fg=TEXT_DIM, font=("Segoe UI", 9)).pack(
            side="left", padx=(12, 0), pady=10, fill="x", expand=True
        )

        # ── Subscription link + QR ──────────────────────────────────────
        top_card = tk.Frame(main, bg=CARD_BG)
        top_card.pack(fill="x", pady=(0, 10))

        top_row = tk.Frame(top_card, bg=CARD_BG)
        top_row.pack(fill="x", padx=16, pady=(8, 8))

        tk.Label(top_row, text="ССЫЛКА:", bg=CARD_BG, fg=TEXT_DIM,
                 font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 6))

        # Left: link display — Entry readonly с видимым текстом
        self.link_var = tk.StringVar(value="")
        self.link_entry = tk.Entry(
            top_row, textvariable=self.link_var, state="readonly",
            font=("Consolas", 9), bg="#f0f0f0", fg="#111",
            relief="flat",
        )
        self.link_entry.pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.link_entry.bind("<Button-1>", lambda e: self.copy_link())
        self.link_entry.bind("<Enter>", lambda e: self.link_entry.config(bg="#e0e0e0"))
        self.link_entry.bind("<Leave>", lambda e: self.link_entry.config(bg="#f0f0f0"))

        # Copy button next to link
        self.link_copy_button = tk.Button(
            top_row, text="📋", bg=CARD_BG, fg=TEXT_DIM,
            font=("Segoe UI", 10), border=0, cursor="hand2",
            padx=8, pady=2, relief="flat", state="disabled",
            command=self.copy_link,
        )
        self.link_copy_button.pack(side="left", padx=(0, 6))
        self.link_copy_button.bind("<Enter>", lambda e: self.link_copy_button.config(bg=HOVER, fg=PRIMARY))
        self.link_copy_button.bind("<Leave>", lambda e: self.link_copy_button.config(bg=CARD_BG, fg=TEXT_DIM))

        # Right: QR code (compact)
        self.qr_canvas = tk.Canvas(
            top_row, width=80, height=80, bg=CARD_BG,
            highlightthickness=0,
        )
        self.qr_canvas.pack(side="right")
        self.qr_label = tk.Label(
            self.qr_canvas, text="", bg=CARD_BG,
            fg=TEXT_DIM, font=("Segoe UI", 8),
        )
        self.qr_label.place(relx=0.5, rely=0.5, anchor="center")

        # ── Progress bar (custom canvas) ────────────────────────────────
        # ── ЗАКОММЕНТИРОВАНО ──
        # prog_frame = tk.Frame(main, bg=CARD_BG)
        # prog_frame.pack(fill="x", pady=(0, 14))
        # tk.Label(prog_frame, text="ПРОЦЕСС", bg=CARD_BG,
        #          fg=TEXT_DIM, font=("Segoe UI", 9, "bold")).pack(
        #     anchor="w", padx=16, pady=(10, 4)
        # )
        # self.progress_canvas = tk.Canvas(
        #     prog_frame, height=8, bg=BORDER, highlightthickness=0,
        # )
        # self.progress_canvas.pack(fill="x", padx=16, pady=(0, 12))
        # self.progress_rect = self.progress_canvas.create_rectangle(
        #     0, 0, 0, 8, fill=PRIMARY, width=0,
        # )
        # self._progress_pct = 0
        # self.progress_canvas.bind("<Configure>", lambda e: self._set_progress(self._progress_pct))

        # Вторая декоративная полоска
        prog2_frame = tk.Frame(main, bg=CARD_BG)
        prog2_frame.pack(fill="x", pady=(0, 14))
        tk.Label(prog2_frame, text="ПОДГОТОВКА", bg=CARD_BG,
                 fg=TEXT_DIM, font=("Segoe UI", 9, "bold")).pack(
            anchor="w", padx=16, pady=(10, 4)
        )
        self.progress2_canvas = tk.Canvas(
            prog2_frame, height=4, bg=BORDER, highlightthickness=0,
        )
        self.progress2_canvas.pack(fill="x", padx=16, pady=(0, 12))
        self.progress2_rect = self.progress2_canvas.create_rectangle(
            0, 0, 0, 4, fill=PRIMARY, width=0,
        )
        self._progress2_pct = 0
        self._progress2_animating = False
        self.progress2_canvas.bind("<Configure>", lambda e: self._set_progress2(self._progress2_pct))

        # ── Log card ────────────────────────────────────────────────────
        log_card = tk.Frame(main, bg=CARD_BG)
        log_card.pack(fill="both", expand=True)
        tk.Label(log_card, text="ЖУРНАЛ РАБОТЫ", bg=CARD_BG,
                 fg=TEXT_DIM, font=("Segoe UI", 9, "bold")).pack(
            anchor="w", padx=16, pady=(12, 6)
        )
        log_inner = tk.Frame(log_card, bg=CARD_BG)
        log_inner.pack(fill="both", expand=True, padx=16, pady=(0, 12))

        self.log_box = tk.Text(
            log_inner, wrap="word", state="disabled",
            font=("Consolas", 9), bg=INPUT_BG, fg=TEXT,
            insertbackground=TEXT, relief="flat",
            padx=12, pady=10, undo=True,
        )
        scroll = ttk.Scrollbar(log_inner, orient="vertical", command=self.log_box.yview)
        self.log_box.configure(yscrollcommand=scroll.set)
        self.log_box.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        # ── Footer ──────────────────────────────────────────────────────
        tk.Label(
            main,
            text="🔍 Открыть сайты — видимый браузер (ручной ввод)\n⚡ Авто — фоновый режим (полная автоматизация)",
            bg=BG, fg=TEXT_DIM, font=("Segoe UI", 9),
            wraplength=720, justify="left",
        ).pack(anchor="w", pady=(10, 0))

    def set_status(self, status, detail, color=None):
        self.status_var.set(status)
        self.detail_var.set(detail)
        if color:
            self.status_label.config(fg=color)

    # ── ЗАКОММЕНТИРОВАНО — полоска ПРОЦЕСС ──
    # def _set_progress(self, pct):
    #     """Smooth animated progress bar."""
    #     self._progress_pct = max(0, min(100, pct))
    #     self._animating = True
    #     self._anim_current = self.progress_canvas.coords(self.progress_rect)[2]
    #     self._animate_progress()
    # 
    # def _animate_progress(self):
    #     """Smoothly animate progress bar to target."""
    #     if not getattr(self, "_animating", False):
    #         return
    #     w = self.progress_canvas.winfo_width() or 500
    #     target = w * self._progress_pct / 100
    #     current = self._anim_current
    #     diff = target - current
    #     if abs(diff) < 1:
    #         self.progress_canvas.coords(self.progress_rect, 0, 0, target, 8)
    #         self._anim_current = target
    #         self._animating = False
    #         return
    #     current += diff * 0.25
    #     self.progress_canvas.coords(self.progress_rect, 0, 0, current, 8)
    #     self._anim_current = current
    #     self.after(16, self._animate_progress)

    def _set_progress(self, pct):
        """No-op — ПРОЦЕСС полоска закоментирована."""
        pass

    def _set_progress2(self, pct):
        """Set target for the decorative progress bar — only grows, never shrinks."""
        current_pct = self._progress2_pct
        self._progress2_pct = max(current_pct, min(100, pct))
        if not self._progress2_animating:
            self._progress2_animating = True
            self._progress2_current = self.progress2_canvas.coords(self.progress2_rect)[2]
            self._animate_progress2()

    def _animate_progress2(self):
        """Smooth slow fill for the decorative progress bar."""
        if not self._progress2_animating:
            return
        w = self.progress2_canvas.winfo_width() or 500
        target = w * self._progress2_pct / 100
        current = self._progress2_current
        diff = target - current
        if abs(diff) < 1:
            self.progress2_canvas.coords(self.progress2_rect, 0, 0, target, 4)
            self._progress2_current = target
            self._progress2_animating = False
            return
        # Фиксированная скорость — пиксели в кадр
        current += (diff > 0 and min(2.0, diff) or max(-2.0, diff))
        self.progress2_canvas.coords(self.progress2_rect, 0, 0, current, 4)
        self._progress2_current = current
        self.after(16, self._animate_progress2)

    # ── ЗАКОММЕНТИРОВАНО — полоска ПРОЦЕСС ──
    # def _update_linear_progress(self):
    #     """Update progress bar to linear time-based value while browser is running."""
    #     if self.proc and self.proc.poll() is None:
    #         if self._progress_start is None:
    #             self._progress_start = datetime.now()
    #         elapsed = (datetime.now() - self._progress_start).total_seconds()
    #         pct = min(100, (elapsed / self._progress_duration) * 100)
    #         self._set_progress(pct)
    #     else:
    #         self._progress_start = None
    #     self.after(500, self._update_linear_progress)

    def load_last_subscription(self):
        """Restore the newest saved link so it can be copied without reopening the browser."""
        try:
            with sqlite3.connect(DB_PATH) as con:
                row = con.execute(
                    "SELECT subscription_url FROM subscriptions ORDER BY id DESC LIMIT 1"
                ).fetchone()
        except sqlite3.Error as exc:
            self.log(f"Не удалось прочитать историю: {exc}", "WARN")
            return
        if not row or not row[0]:
            return
        self.subscription = row[0]
        self.link_var.set(row[0])
        self.link_copy_button.config(state="normal", bg=CARD_BG, fg=PRIMARY)
        self.link_copy_button.config(state="normal", bg=CARD_BG, fg=PRIMARY)
        self.set_status("Ожидание", "Загружена последняя ссылка из истории", SUCCESS)
        self.log("Загружена последняя сохранённая ссылка из истории.")

    def log(self, message, level="INFO"):
        stamp = datetime.now().strftime("%H:%M:%S")
        line = f"[{stamp}] [{level}] {message}\n"
        self.log_box.configure(state="normal")
        # Color by level
        tag = level.lower()
        colors = {"info": TEXT, "warn": WARN, "error": ERROR}
        self.log_box.tag_configure(tag, foreground=colors.get(tag.lower(), TEXT))
        self.log_box.insert("end", line, tag)
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def clear_log(self):
        self.log_box.configure(state="normal")
        self.log_box.delete("1.0", "end")
        self.log_box.configure(state="disabled")
        self.log("Журнал очищен.")

    def _start_worker(self, args, hidden=True):
        """Start browser_worker.py. If hidden=False, show the browser window."""
        if hidden:
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow |= subprocess.SW_HIDE
        else:
            startupinfo = None
        self.last_worker_log_size = WORKER_LOG.stat().st_size if WORKER_LOG.exists() else 0
        with open(WORKER_LOG, "a", encoding="utf-8") as worker_log:
            self.proc = subprocess.Popen(
                [sys.executable, str(APP_DIR / "browser_worker.py")] + args,
                cwd=str(APP_DIR),
                stdout=worker_log,
                stderr=subprocess.STDOUT,
                startupinfo=startupinfo,
            )

    def get_link_visible(self):
        if self.proc and self.proc.poll() is None:
            self.log("Браузер уже работает. Перейди в открытое окно и продолжи.", "WARN")
            self.set_status("Ожидание действия", "Открытый браузер уже запущен", WARN)
            return

        worker = APP_DIR / "browser_worker.py"
        if not worker.exists():
            self.log("Не найден файл browser_worker.py.", "ERROR")
            self.set_status("Ошибка", "Не найден компонент браузера", ERROR)
            return

        self.subscription = ""
        self.link_copy_button.config(state="disabled", bg=CARD_BG, fg=TEXT_DIM)
        self.link_var.set("")
        self.link_copy_button.config(state="disabled", bg=CARD_BG, fg=TEXT_DIM)
        self.open_button.config(bg=CARD_BG, fg=TEXT_DIM)
        self._set_progress(0)
        self._progress2_pct = 0
        self._progress2_current = 0
        try:
            self.last_clipboard = self.clipboard_get()
        except tk.TclError:
            self.last_clipboard = ""

        self.log("Запускаю видимый браузер…")
        self.set_status("Запуск браузера", "Открываю FASTVPN и временную почту", PRIMARY)
        self._set_progress(10)
        try:
            self._start_worker(["--visible"], hidden=False)
            self.log("Процесс браузера запущен. Окно должно появиться на экране.")
            self.log("Открываются две вкладки: FASTVPN и временная почта.")
            self.log("Вручную войди в аккаунт и скопируй ссылку из кабинета.")
            self.set_status("Браузер запущен", "Ожидаю ссылку из буфера обмена", PRIMARY)
            self._set_progress(25)
        except Exception as exc:
            self.log(f"Не удалось запустить браузер: {exc}", "ERROR")
            self.set_status("Ошибка запуска", "Проверь установку компонентов", ERROR)
            self._set_progress(0)

    def get_link_auto(self):
        if self.proc and self.proc.poll() is None:
            self.log("Браузер уже работает. Подожди завершения.", "WARN")
            self.set_status("Ожидание действия", "Открытый браузер уже запущен", WARN)
            return

        worker = APP_DIR / "browser_worker.py"
        if not worker.exists():
            self.log("Не найден файл browser_worker.py.", "ERROR")
            self.set_status("Ошибка", "Не найден компонент браузера", ERROR)
            return

        self.subscription = ""
        self.link_copy_button.config(state="disabled", bg=CARD_BG, fg=TEXT_DIM)
        self.link_var.set("")
        self.link_copy_button.config(state="disabled", bg=CARD_BG, fg=TEXT_DIM)
        self._set_progress(0)
        self._progress2_pct = 0
        self._progress2_current = 0
        try:
            self.last_clipboard = self.clipboard_get()
        except tk.TclError:
            self.last_clipboard = ""

        self.log("Запускаю фоновый браузер (авто)...")
        self.set_status("Авто-режим", "FASTVPN и почта работают в фоне", PRIMARY)
        self._set_progress(10)
        try:
            self._start_worker(["--headless"], hidden=True)
            self.log("Браузер работает в фоне. Ссылка появится автоматически.")
            self.set_status("Авто-режим", "Ожидаю ссылку из буфера обмена", PRIMARY)
            self._set_progress(25)
        except Exception as exc:
            self.log(f"Не удалось запустить браузер: {exc}", "ERROR")
            self.set_status("Ошибка запуска", "Проверь установку компонентов", ERROR)
            self._set_progress(0)

    def tick(self):
        self.check_process()
        self.check_clipboard()
        self.read_worker_log()
        self.after(POLL_MS, self.tick)

    def check_process(self):
        if self.proc and self.proc.poll() is not None:
            code = self.proc.returncode
            self.proc = None
            if code == 0:
                self.log("Окно браузера закрыто.")
                if self.subscription:
                    self._set_progress(100)
                    self.set_status("Готово", "Ссылка получена и сохранена", SUCCESS)
                    self.open_button.config(bg=CARD_BG, fg=TEXT_DIM)  # Сброс цвета
                else:
                    self._set_progress(0)
                    self.set_status("Браузер закрыт", "Можно снова нажать «Получить ссылку»", TEXT_DIM)
                    self.open_button.config(bg=CARD_BG, fg=WARN)  # Жёлтая при ошибке
            else:
                self.log(f"Браузер завершился с кодом {code}. Подробности смотри в browser_worker.log.", "ERROR")
                self.set_status("Ошибка браузера", "См. журнал browser_worker.log", ERROR)
                self._set_progress(0)
                self.open_button.config(bg=CARD_BG, fg=WARN)  # Жёлтая при ошибке

    def check_clipboard(self):
        if self.subscription:
            return
        try:
            current = self.clipboard_get().strip()
        except tk.TclError:
            return
        if not current or current == self.last_clipboard:
            return
        self.last_clipboard = current
        match = URL_RE.search(current)
        if not match:
            return
        candidate = match.group(0).strip().rstrip(".,;:)]}'\"")
        if not candidate or len(candidate) > 12000:
            self.log("Содержимое буфера слишком большое; ссылка не сохранена.", "WARN")
            return
        if candidate == self.subscription:
            return
        self.subscription = candidate
        with sqlite3.connect(DB_PATH) as con:
            already = con.execute(
                "SELECT 1 FROM subscriptions WHERE subscription_url = ? LIMIT 1", (candidate,)
            ).fetchone()
            if not already:
                con.execute(
                    "INSERT INTO subscriptions (created_at,email,subscription_url,note) VALUES (?,?,?,?)",
                    (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "", candidate, "Получено из буфера обмена")
                )
        self.link_var.set(candidate)
        self.link_copy_button.config(state="normal", bg=CARD_BG, fg=PRIMARY)
        self.link_copy_button.config(state="normal", bg=CARD_BG, fg=PRIMARY)
        self._set_progress(100)
        self.set_status("Готово", "Ссылка сохранена локально и готова к копированию", SUCCESS)
        self.log("Обнаружена ссылка в буфере обмена.")
        if already:
            self.log("Такая ссылка уже есть в истории — запись не дублировалась.")
        else:
            self.log("Ссылка сохранена в локальную историю.")

    def read_worker_log(self):
        if not WORKER_LOG.exists():
            return
        try:
            size = WORKER_LOG.stat().st_size
            if size <= self.last_worker_log_size:
                return
            with open(WORKER_LOG, "r", encoding="utf-8", errors="replace") as f:
                f.seek(self.last_worker_log_size)
                new_text = f.read()
            self.last_worker_log_size = size
            for line in new_text.splitlines():
                text = line.strip()
                if not text:
                    continue
                if text.startswith("EMAIL:"):
                    self.copy_mail_address(text[len("EMAIL:"):].strip())
                    continue
                if text.startswith("QR_CODE:"):
                    # Формат: QR_CODE:{base64}|{link}
                    parts = text[len("QR_CODE:"):].split("|", 1)
                    b64 = parts[0].strip()
                    link = parts[1].strip() if len(parts) > 1 else ""
                    self.display_qr_code(b64, link)
                    continue
                self.log(f"Браузер: {text}")
                self.apply_worker_hint(text)
        except OSError:
            pass

    def copy_mail_address(self, address):
        """Put the temp-mail address into the clipboard so it can be pasted into the login form."""
        if not address:
            return
        self.clipboard_clear()
        self.clipboard_append(address)
        self.update()
        self.last_clipboard = address
        self.log("Адрес почты скопирован в буфер обмена.")
        if not self.subscription:
            self.set_status("Браузер запущен", "Адрес почты в буфере — вставь его в форму входа")

    def display_qr_code(self, b64_data, link=""):
        """Display a QR code image from base64 data and store the link."""
        if not b64_data:
            return
        try:
            img_data = base64.b64decode(b64_data)
            img = Image.open(io.BytesIO(img_data))
            img = img.resize((120, 120), Image.LANCZOS)
            tk_img = ImageTk.PhotoImage(img)
            self.qr_canvas.delete("all")
            self.qr_canvas.create_image(60, 60, image=tk_img, anchor="center")
            self.qr_canvas._qr_image = tk_img  # Keep reference
            if hasattr(self, "qr_label") and self.qr_label:
                try:
                    self.qr_label.destroy()
                except Exception:
                    pass
                self.qr_label = None
            self.log("QR код сгенерирован и отображён.")
        except Exception as exc:
            self.log(f"Не удалось отобразить QR код: {exc}", "WARN")

        # Сохраняем ссылку из QR
        if link:
            self.subscription = link
            self.link_var.set(link)
            self.link_copy_button.config(state="normal", bg=CARD_BG, fg=PRIMARY)
            self.link_copy_button.config(state="normal", bg=CARD_BG, fg=PRIMARY)
            self._set_progress(100)
            self._set_progress2(100)
            self.set_status("Готово", "Ссылка получена и QR код отображён", SUCCESS)
            self.log("Ссылка подписки сохранена из QR-кода.")
            # Сохраняем в БД
            try:
                with sqlite3.connect(DB_PATH) as con:
                    already = con.execute(
                        "SELECT 1 FROM subscriptions WHERE subscription_url = ? LIMIT 1", (link,)
                    ).fetchone()
                    if not already:
                        con.execute(
                            "INSERT INTO subscriptions (created_at,email,subscription_url,note) VALUES (?,?,?,?)",
                            (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "", link, "Получено через QR-код")
                        )
            except sqlite3.Error as exc:
                self.log(f"Не удалось сохранить ссылку в БД: {exc}", "WARN")

    def apply_worker_hint(self, text):
        """Translate worker log lines into a friendlier status, without touching a found link."""
        if self.subscription:
            return
        if "FASTVPN загружен" in text:
            self.set_status("Браузер запущен", "FASTVPN открыт — войди и скопируй ссылку подписки", PRIMARY)
            self._set_progress(20)
            self._set_progress2(5)
        elif "Почта загружена" in text:
            self.set_status("Браузер запущен", "Почта открыта во второй вкладке", PRIMARY)
            self._set_progress(35)
            self._set_progress2(10)
        elif "Форма входа открыта" in text:
            self.set_status("Браузер запущен", "Форма входа открыта — вставь адрес почты (Ctrl+V)", PRIMARY)
            self._set_progress(45)
            self._set_progress2(20)
        elif "Не удалось открыть" in text:
            self.set_status("Проблема с сайтом", "Проверь подключение или открой вкладку вручную", ERROR)
        elif "Код найден" in text:
            self._set_progress(60)
            self._set_progress2(35)
        elif "Кнопка" in text and "нажата" in text:
            self._set_progress(75)
            self._set_progress2(55)
        elif "Ссылка подписки" in text and ("найдена" in text or "скопирована" in text):
            self._set_progress(90)
            self._set_progress2(75)

    def _set_progress2(self, pct):
        """Set target for the decorative progress bar — only grows, never shrinks."""
        current_pct = self._progress2_pct
        self._progress2_pct = max(current_pct, min(100, pct))
        self._progress2_animating = True
        self._progress2_current = self.progress2_canvas.coords(self.progress2_rect)[2]
        self._animate_progress2()

    def copy_link(self):
        if not self.subscription:
            self.log("Пока нет сохранённой ссылки. Сначала получи её в кабинете.", "WARN")
            return
        self.clipboard_clear()
        self.clipboard_append(self.subscription)
        self.update()
        self.log("Ссылка скопирована в буфер обмена.")
        self.set_status("Готово", "Ссылка скопирована — можно вставлять её в VPN-клиент", SUCCESS)
        # Brief visual feedback
        self.link_copy_button.config(text="✅", bg=SUCCESS, fg="#fff")
        self.after(1500, lambda: self.link_copy_button.config(
            text="📋", bg=CARD_BG, fg=PRIMARY
        ))

    def on_close(self):
        if self.proc and self.proc.poll() is None:
            self.log("Завершаю браузер перед закрытием приложения…")
            try:
                self.proc.terminate()
                self.proc.wait(timeout=4)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
        self.destroy()

def init_db():
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS subscriptions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                email TEXT,
                subscription_url TEXT NOT NULL,
                note TEXT
            )
        """)

if __name__ == "__main__":
    App().mainloop()
